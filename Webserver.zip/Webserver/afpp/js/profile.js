function prompt1(){
	alert("Save successfully!")
}
